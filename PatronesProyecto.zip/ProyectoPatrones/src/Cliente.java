package sistemaEstudiantil;

// Interfaz para las acciones del cliente
public interface Cliente {
    void actualizarDatosCliente();
}

class ClienteReal implements Cliente {
    private String nombre;

    public ClienteReal(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public void actualizarDatosCliente() {
        System.out.println("Actualizando datos del cliente " + nombre + ".");
    }
}

class ClienteProxy implements Cliente {
    private ClienteReal clienteReal;
    private String nombre;

    public ClienteProxy(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public void actualizarDatosCliente() {
        if (clienteReal == null) {
            clienteReal = new ClienteReal(nombre);
        }
        System.out.println("Proxy: Autenticando cliente...");
        clienteReal.actualizarDatosCliente();
    }
}
