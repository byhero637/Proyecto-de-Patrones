package sistemaEstudiantil;

import java.util.ArrayList;
import java.util.List;

// Interfaz Observador
interface Observador {
    void actualizar(String estado);
}

// Clase Sujeto
class SolicitudBeca {
    private List<Observador> observadores = new ArrayList<>();
    private String estado;

    public void agregarObservador(Observador observador) {
        observadores.add(observador);
    }

    public void eliminarObservador(Observador observador) {
        observadores.remove(observador);
    }

    public void cambiarEstado(String nuevoEstado) {
        this.estado = nuevoEstado;
        notificarObservadores();
    }

    private void notificarObservadores() {
        for (Observador observador : observadores) {
            observador.actualizar(estado);
        }
    }
}

// Clase Observador
class Estudiante implements Observador {
    private String nombre;

    public Estudiante(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public void actualizar(String estado) {
        System.out.println("Notificación para " + nombre + ": El estado de la solicitud de beca ha cambiado a: " + estado);
    }
}
