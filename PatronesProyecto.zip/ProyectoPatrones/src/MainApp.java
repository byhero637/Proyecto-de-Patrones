package sistemaEstudiantil;

public class MainApp {
    public static void main(String[] args) {
        System.out.println("=== Ejecución del Programa con Múltiples Patrones de Diseño ===\n");

        // Patrón Singleton
        System.out.println("Prueba de Singleton:");
        Gestor gestor1 = Gestor.obtenerInstancia();
        Gestor gestor2 = Gestor.obtenerInstancia();
        System.out.println(gestor1 == gestor2 ? "Singleton funciona: Solo hay una instancia." : "Error en Singleton.");

        // Patrón Proxy
        System.out.println("\nPrueba de Proxy:");
        Cliente clienteProxy = new ClienteProxy("Juan Pérez");
        clienteProxy.actualizarDatosCliente();

        // Patrón Decorador
        System.out.println("\nPrueba de Decorador:");
        Servicio solicitudCarnet = new SolicitudCarnetEstudiantil();
        Servicio solicitudConDecorador = new EnvoltorioServicio(solicitudCarnet);
        solicitudConDecorador.ejecutar();

        // Patrón Observador
        System.out.println("\nPrueba de Observador:");
        SolicitudBeca solicitudBeca = new SolicitudBeca();
        Estudiante estudiante1 = new Estudiante("Juan Pérez");
        Estudiante estudiante2 = new Estudiante("Ana Gómez");
        solicitudBeca.agregarObservador(estudiante1);
        solicitudBeca.agregarObservador(estudiante2);
        solicitudBeca.cambiarEstado("En revisión");
        solicitudBeca.cambiarEstado("Aprobada");

        // Patrón Plantilla de Método
        System.out.println("\nPrueba de Plantilla de Método:");
        ActualizarDatosCliente clienteIndividual = new ActualizarDatosClienteIndividual();
        clienteIndividual.actualizarDatos();
        
        ActualizarDatosCliente clienteEmpresarial = new ActualizarDatosClienteEmpresarial();
        clienteEmpresarial.actualizarDatos();
    }
}
