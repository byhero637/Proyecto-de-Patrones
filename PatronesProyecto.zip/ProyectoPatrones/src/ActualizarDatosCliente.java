package sistemaEstudiantil;

// Clase abstracta que define el algoritmo base
public abstract class ActualizarDatosCliente {
    
    // Método plantilla que define el flujo del algoritmo
    public final void actualizarDatos() {
        verificarDatosActuales();
        if (validarNuevosDatos()) {
            guardarDatosActualizados();
            notificarCliente();
        } else {
            System.out.println("Error: Los datos nuevos no son válidos.");
        }
    }

    // Pasos comunes implementados en la clase base
    protected void verificarDatosActuales() {
        System.out.println("Verificando los datos actuales del cliente...");
    }

    protected void guardarDatosActualizados() {
        System.out.println("Guardando los datos actualizados en el sistema...");
    }

    // Métodos abstractos que deben ser implementados por las subclases
    protected abstract boolean validarNuevosDatos();
    protected abstract void notificarCliente();
}

// Subclases específicas
class ActualizarDatosClienteIndividual extends ActualizarDatosCliente {
    @Override
    protected boolean validarNuevosDatos() {
        System.out.println("Validando los nuevos datos para un cliente individual...");
        return true; // Simulación
    }

    @Override
    protected void notificarCliente() {
        System.out.println("Notificando al cliente individual sobre los cambios realizados.");
    }
}

class ActualizarDatosClienteEmpresarial extends ActualizarDatosCliente {
    @Override
    protected boolean validarNuevosDatos() {
        System.out.println("Validando los nuevos datos para un cliente empresarial...");
        return false; // Simulación
    }

    @Override
    protected void notificarCliente() {
        System.out.println("Notificando al representante de la empresa sobre los cambios realizados.");
    }
}
