package sistemaEstudiantil;

public class Gestor {
    private static Gestor instancia;

    // Constructor privado para evitar la creación directa
    private Gestor() {
        System.out.println("Instancia de Gestor creada.");
    }

    // Método estático para obtener la única instancia
    public static Gestor obtenerInstancia() {
        if (instancia == null) {
            instancia = new Gestor();
        }
        return instancia;
    }
}
