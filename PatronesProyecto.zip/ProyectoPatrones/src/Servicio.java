package sistemaEstudiantil;

// Interfaz para servicios estudiantiles
public interface Servicio {
    void ejecutar();
}

class SolicitudCarnetEstudiantil implements Servicio {
    @Override
    public void ejecutar() {
        System.out.println("Realizando solicitud para obtener un carnet estudiantil.");
    }
}

class EnvoltorioServicio implements Servicio {
    private Servicio servicio;

    public EnvoltorioServicio(Servicio servicio) {
        this.servicio = servicio;
    }

    @Override
    public void ejecutar() {
        servicio.ejecutar();
        System.out.println("Ejecución adicional en el envoltorio del servicio.");
    }
}
